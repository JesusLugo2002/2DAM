package com.docencia.aed.entity;

public enum EventStatus {
    DRAFT,
    PENDING_APPROVAL,
    APPROVED,
    REJECTED
}
