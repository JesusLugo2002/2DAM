package com.docencia.ficheros.ficheros_serializables;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FicherosSerializablesApplication {

	public static void main(String[] args) {
		SpringApplication.run(FicherosSerializablesApplication.class, args);
	}

}
