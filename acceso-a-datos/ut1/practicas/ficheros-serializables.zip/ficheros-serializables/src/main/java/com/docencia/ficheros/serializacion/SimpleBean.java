package com.docencia.ficheros.serializacion;

public class SimpleBean {
    private int x = 1;
    private int y = 2;

    public int getX() {
        return this.x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return this.y;
    }

    public void setY(int y) {
        this.y = y;
    }

}
