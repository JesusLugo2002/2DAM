package com.docencia.com.examen.procesos.domain;

public enum Job {
    DF;
}
